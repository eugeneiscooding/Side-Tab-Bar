//
//  ContentView.swift
//  Side Tab Bar
//
//  Created by Kavsoft on 13/05/20.
//  Copyright © 2020 Kavsoft. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


struct Home : View {
    
    @State var index = 0
    
    var body: some View{
        
        HStack(spacing: 0){
            
            VStack{
                
                Button(action: {
                    
                }) {
                    
                    Image("menu")
                        .renderingMode(.original)
                        .resizable()
                        .frame(width: 22, height: 22)
                    
                }
                .padding(.top,UIApplication.shared.windows.first?.safeAreaInsets.top)
                
                Button(action: {
                    
                }) {
                    
                    Image("search")
                        .renderingMode(.original)
                        .resizable()
                        .frame(width: 22, height: 22)
                    
                }.padding(.top,30)
                
                // now going to create side tabbar...
                //follow me...
                
                Group{
                    
                    
                    Button(action: {
                        
                        self.index = 3
                        
                    }) {
                        
                        VStack{
                            
                            Text("My Profile")
                            // Fixed width because we re going to rotate views....
                                
                            .frame(width: 120,height: 35)
                            
                            //changing textcolor based on index...
                            .foregroundColor(self.index == 3 ? Color.white : Color.black)
                            
                        }
                        //changing bg color based on index...
                        .background(Color("Color1").opacity(self.index == 3 ? 1 : 0))
                        .clipShape(CShape1())
                        
                    }
                    .rotationEffect(.init(degrees: -90))
                    .padding(.top, 80)
                    
                    Spacer(minLength: 0)
                    
                    // adding remaining tabs....
                    
                    Button(action: {
                        
                        self.index = 2
                        
                    }) {
                        
                        VStack{
                            
                            Text("Notifications")
                            // Fixed width because we re going to rotate views....
                                
                            .frame(width: 120,height: 35)
                            
                            //changing textcolor based on index...
                            .foregroundColor(self.index == 2 ? Color.white : Color.black)
                            
                        }
                        //changing bg color based on index...
                        .background(Color("Color1").opacity(self.index == 2 ? 1 : 0))
                        .clipShape(CShape1())
                        
                    }
                    .rotationEffect(.init(degrees: -90))
                    
                    Spacer(minLength: 0)
                    
                    Button(action: {
                        
                        self.index = 1
                        
                    }) {
                        
                        VStack{
                            
                            Text("Invoice")
                            // Fixed width because we re going to rotate views....
                                
                            .frame(width: 120,height: 35)
                            
                            //changing textcolor based on index...
                            .foregroundColor(self.index == 1 ? Color.white : Color.black)
                            
                        }
                        //changing bg color based on index...
                        .background(Color("Color1").opacity(self.index == 1 ? 1 : 0))
                        .clipShape(CShape1())
                        
                    }
                    .rotationEffect(.init(degrees: -90))
                    
                    Spacer(minLength: 0)
                    
                    Button(action: {
                        
                        self.index = 0
                        
                    }) {
                        
                        VStack{
                            
                            Text("Home")
                            // Fixed width because we re going to rotate views....
                                
                            .frame(width: 120,height: 35)
                            
                            //changing textcolor based on index...
                            .foregroundColor(self.index == 0 ? Color.white : Color.black)
                            
                        }
                        //changing bg color based on index...
                        .background(Color("Color1").opacity(self.index == 0 ? 1 : 0))
                        .clipShape(CShape1())
                        
                    }
                    .rotationEffect(.init(degrees: -90))
                    
                    Spacer(minLength: 0)
                    
                    Button(action: {
                        
                    }) {
                        
                        Image("shop")
                            .renderingMode(.original)
                            .resizable()
                            .frame(width: 25, height: 30)
                    }
                    .padding(.bottom)
                    .padding(.bottom, UIApplication.shared.windows.first?.safeAreaInsets.bottom)
                    
                    // due to all edges is ignored we using this padding...

                }
                
                // due to this spacer there is space in bottom

            }
            .padding(.vertical)
            // Fixed Width....
            .frame(width: 85)
            .background(Color("Color"))
            .clipShape(CShape())
            
            
            // now were going to create main view....
            
            GeometryReader{_ in
                
                VStack{
                    
                    // changing tabs based on tabs...
                    
                    if self.index == 0{
                        
                        MainView()
                    }
                    else if self.index == 1{
                        
                        Invoice()
                    }
                    else if self.index == 2{
                        
                        Notifications()
                    }
                    else{
                        
                        Profile()
                    }
                    
                }
                .padding(.top, UIApplication.shared.windows.first?.safeAreaInsets.top)
                 .padding(.bottom, UIApplication.shared.windows.first?.safeAreaInsets.bottom)
                
                // due to all edges are ignored...
            }
        }
        .edgesIgnoringSafeArea(.all)
    }
}

// creating Custom corner radius for only two ends....

struct CShape : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.topRight,.bottomRight], cornerRadii: CGSize(width: 35, height: 35))
        
        return Path(path.cgPath)
    }
}

struct CShape1 : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.topLeft,.bottomRight], cornerRadii: CGSize(width: 15, height: 15))
        
        return Path(path.cgPath)
    }
}

struct MainView : View {
    
    @State var index = 0
    
    var body: some View{
        
        VStack{
            
            HStack{
                
                Text("Food & Delivery")
                    .font(.title)
                    .fontWeight(.bold)
                
                Spacer()
            }
            .padding(.top, 20)
            .padding(.horizontal, 20)
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                
                // Swipe Menu....
                
                HStack{
                    
                    Button(action: {
                        
                        self.index = 0
                        
                    }) {
                        
                        Text("Asian")
                        // changing color based on index....
                        .foregroundColor(self.index == 0 ? Color("Color1") : Color.black.opacity(0.7))
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                    }
                    .background(self.index == 0 ? Color.black.opacity(0.06) : Color.clear)
                    .clipShape(CShape1())
                    
                    Button(action: {
                        
                        self.index = 1
                        
                    }) {
                        
                        Text("American")
                        // changing color based on index....
                        .foregroundColor(self.index == 1 ? Color("Color1") : Color.black.opacity(0.7))
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                    }
                    .background(self.index == 1 ? Color.black.opacity(0.06) : Color.clear)
                    .clipShape(CShape1())
                    
                    Button(action: {
                        
                        self.index = 2
                        
                    }) {
                        
                        Text("Mexican")
                        // changing color based on index....
                        .foregroundColor(self.index == 2 ? Color("Color1") : Color.black.opacity(0.7))
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                    }
                    .background(self.index == 2 ? Color.black.opacity(0.06) : Color.clear)
                    .clipShape(CShape1())
                    
                    Button(action: {
                        
                        self.index = 3
                        
                    }) {
                        
                        Text("Mexican")
                        // changing color based on index....
                        .foregroundColor(self.index == 3 ? Color("Color1") : Color.black.opacity(0.7))
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                    }
                    .background(self.index == 3 ? Color.black.opacity(0.06) : Color.clear)
                    .clipShape(CShape1())
                    
                    Button(action: {
                        
                        self.index = 4
                        
                    }) {
                        
                        
                        Text("Chinese")
                        // changing color based on index....
                        .foregroundColor(self.index == 4 ? Color("Color1") : Color.black.opacity(0.7))
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                    }
                    .background(self.index == 4 ? Color.black.opacity(0.06) : Color.clear)
                    .clipShape(CShape1())
                }
                .padding(.horizontal, 20)
            }
            .padding(.top, 25)
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: 20){
                    
                    ForEach(data){i in
                        
                        VStack{
                            
                            Image(i.image)
                            .resizable()
                            .frame(width: 125, height: 125)
                            .clipShape(Circle())
                            
                            Text(i.price)
                                .fontWeight(.bold)
                                .font(.title)
                                .foregroundColor(Color("Color1"))
                                .padding(.top)
                            
                            Text(i.name)
                                .padding(.vertical, 20)
                            
                            Button(action: {
                                
                            }) {
                                
                                Text("Add")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal, 35)
                            }
                            .background(Color("Color1"))
                            .clipShape(CShape1())
                        }
                        .padding(.vertical)
                        .padding(.horizontal, 40)
                        .background(Color.black.opacity(0.05))
                        .clipShape(CShape1())
                    }
                }
                .padding(.horizontal, 20)
            }
            .padding(.top, 25)
            
            
            Spacer()
            
            
            HStack{
                
                Spacer()
                
                Button(action: {
                    
                }) {
                    
                    Text("View All")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.horizontal, 35)
                        .padding(.vertical)
                }
                .background(Color("Color1"))
                .clipShape(CShape1())
            }
            .padding(.horizontal, 20)
            
        }
    }
}

// tabs....

struct Profile : View {
    
    var body: some View{
        
        VStack{
            
            Text("Profile")
                .font(.title)
                .fontWeight(.bold)
        }
    }
}

struct Invoice : View {
    
    var body: some View{
        
        VStack{
            
            Text("Invoice")
                .font(.title)
                .fontWeight(.bold)
        }
    }
}

struct Notifications : View {
    
    var body: some View{
        
        VStack{
            
            Text("Notifications")
                .font(.title)
                .fontWeight(.bold)
        }
    }
}

// sample data type and data....

struct Type : Identifiable {
    
    var id : Int
    var name : String
    var cName : String
    var price : String
    var image : String
}

var data = [

    Type(id: 0, name: "Rice Stick Noodles", cName: "Italian", price: "$18",image: "rice"),
    
    Type(id: 1, name: "Mung Bean Noodles", cName: "Chinese", price: "$29",image: "bean")
]
